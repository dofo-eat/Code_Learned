#ifndef _HEART_BEAT_H
#define _HEART_BEAT_H
void *heart_beat(void *arg);
#endif
