#ifndef _SERVER_EXIT_H
#define _SERVER_EXIT_H
void server_exit(int signum);
#endif
