#ifndef _SHOW_STRENGTH_H
#define _SHOW_STRENGTH_H
void show_strength();
#endif
