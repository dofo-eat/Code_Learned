/*************************************************************************
	> File Name: ball_status.h
	> Author: dofo-eat
	> Mail:2354787023@qq.com 
	> Created Time: 2020年07月02日 星期四 18时17分44秒
 ************************************************************************/

#ifndef _BALL_STATUS_H
#define _BALL_STATUS_H
int can_kick(struct Point *loc, int strength);
#endif
