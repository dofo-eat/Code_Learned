char conf_ans[50];
