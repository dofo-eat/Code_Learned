#ifndef _SEND_CHAT_H
#define _SEND_CHAT_H
void send_chat();
#endif
