#ifndef _SERVER_RE_DRAW_H
#define _SERVER_RE_DRAW_H
void re_draw();
#endif
